import React from "react";

const NAV_ITEMS = [
  { id: "dashboard", icon: "🏠", label: "Dashboard"    },
  { id: "matches",   icon: "🏏", label: "Matches"      },
  { id: "live",      icon: "📡", label: "Live Scoring" },
  { id: "past",      icon: "📋", label: "Past Match"   },
  { id: "teams",     icon: "👥", label: "Teams"        },
  { id: "players",   icon: "🧑", label: "Players"      },
  { id: "venues",    icon: "🏟️", label: "Venues"       },
  { id: "stats",     icon: "📊", label: "Stats"        },
];

export default function Nav({ page, setPage }) {
  return (
    <aside style={{
      width: 220, minHeight: "100vh", background: "#1B5E20",
      position: "fixed", left: 0, top: 0, bottom: 0,
      display: "flex", flexDirection: "column", zIndex: 100,
    }}>
      {/* Logo */}
      <div style={{
        padding: "28px 20px 20px",
        borderBottom: "1px solid rgba(255,255,255,0.12)",
      }}>
        <div style={{ fontSize: 22, fontWeight: 800, color: "#FFFFFF", lineHeight: 1.1 }}>
          🏏 CricScore
        </div>
      </div>

      {/* Nav items */}
      <nav style={{ flex: 1, paddingTop: 8 }}>
        {NAV_ITEMS.map((n) => {
          const active = page === n.id;
          return (
            <button
              key={n.id}
              onClick={() => setPage(n.id)}
              style={{
                display: "flex", alignItems: "center", gap: 12,
                width: "100%", padding: "12px 20px",
                background: active ? "rgba(255,255,255,0.15)" : "transparent",
                border: "none", cursor: "pointer",
                color: active ? "#FFD54F" : "rgba(255,255,255,0.85)",
                fontSize: 13, fontWeight: active ? 700 : 400,
                borderLeft: active ? "3px solid #FFD54F" : "3px solid transparent",
                textAlign: "left", transition: "all 0.15s",
              }}
            >
              <span style={{ fontSize: 16 }}>{n.icon}</span>
              {n.label}
            </button>
          );
        })}
      </nav>

      <div style={{ padding: "16px 20px", fontSize: 11, color: "rgba(255,255,255,0.3)" }}>
        Oracle XE · Node.js · React
      </div>
    </aside>
  );
}
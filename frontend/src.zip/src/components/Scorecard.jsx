import React from "react";

const th = { padding: "10px 14px", textAlign: "left", fontSize: 11, fontWeight: 700,
             color: "#666", textTransform: "uppercase", letterSpacing: "0.5px",
             borderBottom: "1px solid #E5E0D8", background: "#FAFAF8" };
const td = { padding: "10px 14px", fontSize: 13, borderBottom: "1px solid #F0EDE8", color: "#1A1A1A" };

export default function Scorecard({ innings }) {
  if (!innings || !innings.length) return <p style={{ color: "#888" }}>No scorecard data.</p>;

  return (
    <div>
      {innings.map((inn) => (
        <div key={inn.INNING_NUMBER} style={{ marginBottom: 32 }}>
          {/* Inning header */}
          <div style={{
            background: "#1B5E20", color: "#FFF",
            padding: "12px 20px", borderRadius: "10px 10px 0 0",
            display: "flex", justifyContent: "space-between", alignItems: "center",
          }}>
            <div>
              <span style={{ fontWeight: 700, fontSize: 15 }}>
                Inning {inn.INNING_NUMBER}: {inn.BATTING_TEAM}
              </span>
              <span style={{ fontSize: 12, marginLeft: 12, opacity: 0.8 }}>
                vs {inn.BOWLING_TEAM}
              </span>
            </div>
            <div style={{ fontWeight: 800, fontSize: 20 }}>
              {inn.TOTAL_RUNS}/{inn.TOTAL_WICKETS}
              <span style={{ fontSize: 13, fontWeight: 400, marginLeft: 8, opacity: 0.85 }}>
                ({inn.COMPLETED_OVERS} ov)
              </span>
            </div>
          </div>

          {/* Batting table */}
          <div style={{ overflowX: "auto", border: "1px solid #E5E0D8", borderTop: "none" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  <th style={th}>Batsman</th>
                  <th style={{ ...th, textAlign: "right" }}>R</th>
                  <th style={{ ...th, textAlign: "right" }}>B</th>
                  <th style={{ ...th, textAlign: "right" }}>4s</th>
                  <th style={{ ...th, textAlign: "right" }}>6s</th>
                  <th style={{ ...th, textAlign: "right" }}>SR</th>
                  <th style={th}>Dismissal</th>
                </tr>
              </thead>
              <tbody>
                {(inn.batting || []).map((b, i) => (
                  <tr key={i} style={{ background: i % 2 === 0 ? "#FFF" : "#FAFAF8" }}>
                    <td style={{ ...td, fontWeight: 600 }}>{b.PLAYER_NAME}</td>
                    <td style={{ ...td, textAlign: "right", fontWeight: 700 }}>{b.RUNS}</td>
                    <td style={{ ...td, textAlign: "right" }}>{b.BALLS}</td>
                    <td style={{ ...td, textAlign: "right" }}>{b.FOURS}</td>
                    <td style={{ ...td, textAlign: "right" }}>{b.SIXES}</td>
                    <td style={{ ...td, textAlign: "right" }}>{b.STRIKE_RATE || "-"}</td>
                    <td style={{ ...td, fontSize: 12, color: "#666" }}>
                      {b.OUT_STATUS === "Not Out"
                        ? <span style={{ color: "#2E7D32", fontWeight: 600 }}>not out</span>
                        : `${b.DISMISSAL_TYPE || ""} ${b.FIELDER ? "c " + b.FIELDER : ""} ${b.DISMISSAL_BOWLER ? "b " + b.DISMISSAL_BOWLER : ""}`.trim()
                      }
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Bowling table */}
          <div style={{ marginTop: 16, overflowX: "auto", border: "1px solid #E5E0D8", borderRadius: 8 }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  <th style={th}>Bowler</th>
                  <th style={{ ...th, textAlign: "right" }}>O</th>
                  <th style={{ ...th, textAlign: "right" }}>R</th>
                  <th style={{ ...th, textAlign: "right" }}>W</th>
                  <th style={{ ...th, textAlign: "right" }}>Econ</th>
                  <th style={{ ...th, textAlign: "right" }}>Maidens</th>
                </tr>
              </thead>
              <tbody>
                {(inn.bowling || []).map((b, i) => (
                  <tr key={i} style={{ background: i % 2 === 0 ? "#FFF" : "#FAFAF8" }}>
                    <td style={{ ...td, fontWeight: 600 }}>{b.PLAYER_NAME}</td>
                    <td style={{ ...td, textAlign: "right" }}>{b.OVERS}</td>
                    <td style={{ ...td, textAlign: "right" }}>{b.RUNS_CONCEDED}</td>
                    <td style={{ ...td, textAlign: "right", fontWeight: 700, color: b.WICKETS > 0 ? "#C62828" : "#1A1A1A" }}>{b.WICKETS}</td>
                    <td style={{ ...td, textAlign: "right" }}>{b.ECONOMY}</td>
                    <td style={{ ...td, textAlign: "right" }}>{b.MAIDENS}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}
    </div>
  );
}
import React, { useState } from "react";
import Dashboard from "./pages/Dashboard";
import Matches from "./pages/Matches";
import LiveScoring from "./pages/LiveScoring";
import PastMatch from "./pages/PastMatch";
import Teams from "./pages/Teams";
import Players from "./pages/Players";
import Venues from "./pages/Venues";
import Stats from "./pages/Stats";
import Nav from "./components/Nav";

export default function App() {
  const [page, setPage] = useState("dashboard");
  const [selectedMatch, setSelectedMatch] = useState(null);

  const renderPage = () => {
    switch (page) {
      case "dashboard": return <Dashboard setPage={setPage} setSelectedMatch={setSelectedMatch} />;
      case "matches":   return <Matches setPage={setPage} setSelectedMatch={setSelectedMatch} selectedMatch={selectedMatch} />;
      case "live":      return <LiveScoring />;
      case "past":      return <PastMatch />;
      case "teams":     return <Teams />;
      case "players":   return <Players />;
      case "venues":    return <Venues />;
      case "stats":     return <Stats />;
      default:          return <Dashboard setPage={setPage} setSelectedMatch={setSelectedMatch} />;
    }
  };

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "#F5F3EE", fontFamily: "'Segoe UI', sans-serif" }}>
      <Nav page={page} setPage={setPage} />
      <main style={{ marginLeft: 220, flex: 1, padding: "32px 36px", minHeight: "100vh" }}>
        {renderPage()}
      </main>
    </div>
  );
}
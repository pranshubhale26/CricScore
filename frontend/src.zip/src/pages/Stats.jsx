import React, { useEffect, useState } from "react";
import axios from "axios";

const API = "http://localhost:5000/api";

export default function Stats() {
  const [tab, setTab]           = useState("batting");
  const [batting, setBatting]   = useState([]);
  const [bowling, setBowling]   = useState([]);
  const [standings, setStandings] = useState([]);
  const [audit, setAudit]       = useState([]);
  const [loading, setLoading]   = useState(true);

  useEffect(() => {
    Promise.all([
      axios.get(`${API}/stats/batting`),
      axios.get(`${API}/stats/bowling`),
      axios.get(`${API}/stats/standings`),
      axios.get(`${API}/stats/audit`),
    ]).then(([b, bwl, st, au]) => {
      setBatting(b.data);
      setBowling(bwl.data);
      setStandings(st.data);
      setAudit(au.data);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  const th = { padding: "10px 14px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "#666", textTransform: "uppercase", letterSpacing: "0.5px", borderBottom: "1px solid #E5E0D8", background: "#FAFAF8" };
  const td = { padding: "10px 14px", fontSize: 13, borderBottom: "1px solid #F0EDE8" };

  const tabs = [
    { id: "batting",   label: "🏏 Batting"   },
    { id: "bowling",   label: "⚾ Bowling"   },
    { id: "standings", label: "🏆 Standings" },
    { id: "audit",     label: "🔍 Audit Log" },
  ];

  return (
    <div>
      <h1 style={{ fontSize: 24, fontWeight: 800, marginBottom: 24 }}>Statistics</h1>

      {/* Tabs */}
      <div style={{ display: "flex", gap: 8, marginBottom: 24, borderBottom: "2px solid #E5E0D8", paddingBottom: 0 }}>
        {tabs.map(t => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            style={{
              background: "none", border: "none", cursor: "pointer",
              padding: "10px 18px", fontSize: 14, fontWeight: tab === t.id ? 700 : 400,
              color: tab === t.id ? "#1B5E20" : "#888",
              borderBottom: tab === t.id ? "3px solid #1B5E20" : "3px solid transparent",
              marginBottom: -2, transition: "all 0.15s",
            }}
          >{t.label}</button>
        ))}
      </div>

      {loading ? <div style={{ color: "#888" }}>Loading...</div> : (
        <>
          {/* Batting */}
          {tab === "batting" && (
            <div style={{ background: "#FFF", border: "1px solid #E5E0D8", borderRadius: 12, overflow: "hidden" }}>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr>
                    <th style={th}>#</th>
                    <th style={th}>Player</th>
                    <th style={th}>Team</th>
                    <th style={{ ...th, textAlign: "right" }}>Inn</th>
                    <th style={{ ...th, textAlign: "right" }}>Runs</th>
                    <th style={{ ...th, textAlign: "right" }}>HS</th>
                    <th style={{ ...th, textAlign: "right" }}>Avg</th>
                    <th style={{ ...th, textAlign: "right" }}>SR</th>
                    <th style={{ ...th, textAlign: "right" }}>4s</th>
                    <th style={{ ...th, textAlign: "right" }}>6s</th>
                  </tr>
                </thead>
                <tbody>
                  {batting.map((p, i) => (
                    <tr key={i} style={{ background: i % 2 === 0 ? "#FFF" : "#FAFAF8" }}>
                      <td style={{ ...td, color: "#888", fontWeight: 600 }}>{i + 1}</td>
                      <td style={{ ...td, fontWeight: 700 }}>{p.PLAYER_NAME}</td>
                      <td style={{ ...td, color: "#666" }}>{p.TEAM_NAME}</td>
                      <td style={{ ...td, textAlign: "right" }}>{p.INNINGS_BATTED}</td>
                      <td style={{ ...td, textAlign: "right", fontWeight: 800, color: "#1B5E20" }}>{p.TOTAL_RUNS}</td>
                      <td style={{ ...td, textAlign: "right" }}>{p.HIGHEST_SCORE}</td>
                      <td style={{ ...td, textAlign: "right" }}>{p.BATTING_AVG}</td>
                      <td style={{ ...td, textAlign: "right" }}>{p.STRIKE_RATE}</td>
                      <td style={{ ...td, textAlign: "right" }}>{p.TOTAL_FOURS}</td>
                      <td style={{ ...td, textAlign: "right" }}>{p.TOTAL_SIXES}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Bowling */}
          {tab === "bowling" && (
            <div style={{ background: "#FFF", border: "1px solid #E5E0D8", borderRadius: 12, overflow: "hidden" }}>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr>
                    <th style={th}>#</th>
                    <th style={th}>Player</th>
                    <th style={th}>Team</th>
                    <th style={{ ...th, textAlign: "right" }}>Overs</th>
                    <th style={{ ...th, textAlign: "right" }}>Runs</th>
                    <th style={{ ...th, textAlign: "right" }}>Wkts</th>
                    <th style={{ ...th, textAlign: "right" }}>Econ</th>
                    <th style={{ ...th, textAlign: "right" }}>Avg</th>
                    <th style={{ ...th, textAlign: "right" }}>Maidens</th>
                  </tr>
                </thead>
                <tbody>
                  {bowling.map((p, i) => (
                    <tr key={i} style={{ background: i % 2 === 0 ? "#FFF" : "#FAFAF8" }}>
                      <td style={{ ...td, color: "#888", fontWeight: 600 }}>{i + 1}</td>
                      <td style={{ ...td, fontWeight: 700 }}>{p.PLAYER_NAME}</td>
                      <td style={{ ...td, color: "#666" }}>{p.TEAM_NAME}</td>
                      <td style={{ ...td, textAlign: "right" }}>{p.TOTAL_OVERS}</td>
                      <td style={{ ...td, textAlign: "right" }}>{p.TOTAL_RUNS}</td>
                      <td style={{ ...td, textAlign: "right", fontWeight: 800, color: "#C62828" }}>{p.TOTAL_WICKETS}</td>
                      <td style={{ ...td, textAlign: "right" }}>{p.ECONOMY}</td>
                      <td style={{ ...td, textAlign: "right" }}>{p.BOWLING_AVG ?? "-"}</td>
                      <td style={{ ...td, textAlign: "right" }}>{p.TOTAL_MAIDENS}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Standings */}
          {tab === "standings" && (
            <div style={{ background: "#FFF", border: "1px solid #E5E0D8", borderRadius: 12, overflow: "hidden" }}>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr>
                    <th style={th}>#</th>
                    <th style={th}>Team</th>
                    <th style={{ ...th, textAlign: "right" }}>Played</th>
                    <th style={{ ...th, textAlign: "right" }}>Won</th>
                    <th style={{ ...th, textAlign: "right" }}>Lost</th>
                    <th style={{ ...th, textAlign: "right" }}>Win %</th>
                  </tr>
                </thead>
                <tbody>
                  {standings.map((t, i) => (
                    <tr key={i} style={{ background: i === 0 ? "#F1F8E9" : i % 2 === 0 ? "#FFF" : "#FAFAF8" }}>
                      <td style={{ ...td, fontWeight: 700, color: i === 0 ? "#2E7D32" : "#888" }}>{i + 1}</td>
                      <td style={{ ...td, fontWeight: 700 }}>{t.TEAM_NAME}</td>
                      <td style={{ ...td, textAlign: "right" }}>{t.PLAYED}</td>
                      <td style={{ ...td, textAlign: "right", color: "#2E7D32", fontWeight: 700 }}>{t.WON}</td>
                      <td style={{ ...td, textAlign: "right", color: "#C62828" }}>{t.LOST}</td>
                      <td style={{ ...td, textAlign: "right", fontWeight: 700 }}>{t.WIN_PCT}%</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Audit */}
          {tab === "audit" && (
            <div style={{ background: "#FFF", border: "1px solid #E5E0D8", borderRadius: 12, overflow: "hidden" }}>
              <div style={{ padding: "12px 16px", borderBottom: "1px solid #E5E0D8", fontSize: 13, color: "#666" }}>
                Auto-generated by Oracle triggers. Every INSERT/UPDATE/DELETE on key tables is logged here.
              </div>
              <table style={{ width: "100%", borderCollapse: "collapse" }}>
                <thead>
                  <tr>
                    <th style={th}>Table</th>
                    <th style={th}>Operation</th>
                    <th style={th}>Record ID</th>
                    <th style={th}>Changed By</th>
                    <th style={th}>Time</th>
                    <th style={th}>Description</th>
                  </tr>
                </thead>
                <tbody>
                  {audit.map((a, i) => {
                    const opColor = { INSERT: "#2E7D32", UPDATE: "#1565C0", DELETE: "#C62828" };
                    return (
                      <tr key={i} style={{ background: i % 2 === 0 ? "#FFF" : "#FAFAF8" }}>
                        <td style={{ ...td, fontWeight: 600 }}>{a.TABLE_NAME}</td>
                        <td style={td}>
                          <span style={{ background: opColor[a.OPERATION] + "22", color: opColor[a.OPERATION], fontSize: 11, fontWeight: 700, padding: "2px 8px", borderRadius: 10 }}>
                            {a.OPERATION}
                          </span>
                        </td>
                        <td style={{ ...td, color: "#888" }}>{a.RECORD_ID}</td>
                        <td style={{ ...td, color: "#666" }}>{a.CHANGED_BY}</td>
                        <td style={{ ...td, fontSize: 11, color: "#888" }}>{a.CHANGED_AT}</td>
                        <td style={{ ...td, fontSize: 12, color: "#666" }}>{a.DESCRIPTION}</td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          )}
        </>
      )}
    </div>
  );
}
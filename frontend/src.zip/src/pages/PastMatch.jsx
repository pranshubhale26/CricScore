import React, { useState, useEffect } from "react";
import axios from "axios";

const API = "http://localhost:5000/api";

export default function PastMatch() {
  const [teams, setTeams]   = useState([]);
  const [venues, setVenues] = useState([]);
  const [players, setPlayers] = useState([]);
  const [msg, setMsg]       = useState("");
  const [step, setStep]     = useState(1);

  const [matchForm, setMatchForm] = useState({
    team1_id:"", team2_id:"", venue_id:"",
    match_date:"", match_format:"ODI",
    toss_winner_id:"", toss_decision:"Bat",
  });
  const [matchId, setMatchId]   = useState(null);

  const [result, setResult] = useState({
    winning_team_id:"", win_margin:"", win_margin_type:"Runs",
    man_of_match:"", result_description:"",
  });

  const [innings, setInnings] = useState([
    { inning_number:1, batting_team_id:"", bowling_team_id:"", total_runs:"", total_wickets:"", completed_overs:"", extras_total:"", batting:[], bowling:[] },
    { inning_number:2, batting_team_id:"", bowling_team_id:"", total_runs:"", total_wickets:"", completed_overs:"", extras_total:"", batting:[], bowling:[] },
  ]);

  useEffect(() => {
    Promise.all([axios.get(`${API}/teams`), axios.get(`${API}/venues`)])
      .then(([t,v]) => { setTeams(t.data); setVenues(v.data); });
  }, []);

  useEffect(() => {
    if (matchForm.team1_id && matchForm.team2_id) {
      Promise.all([
        axios.get(`${API}/players?team_id=${matchForm.team1_id}`),
        axios.get(`${API}/players?team_id=${matchForm.team2_id}`),
      ]).then(([r1, r2]) => setPlayers([...r1.data, ...r2.data]));
    }
  }, [matchForm.team1_id, matchForm.team2_id]);

  const inp = { width: "100%", padding: "9px 12px", borderRadius: 8, border: "1px solid #DDD", fontSize: 13, boxSizing: "border-box", marginBottom: 10, background: "#FFF" };
  const btn = (bg="#1B5E20") => ({ background: bg, color: "#FFF", border: "none", borderRadius: 8, padding: "10px 20px", cursor: "pointer", fontSize: 13, fontWeight: 600, marginRight: 10 });

  const showMsg = (m) => { setMsg(m); setTimeout(() => setMsg(""), 5000); };

  const createMatch = async () => {
    try {
      const r = await axios.post(`${API}/matches`, matchForm);
      setMatchId(r.data.match_id);
      setStep(2);
      showMsg("✅ Match created! Now enter inning data.");
    } catch (e) { showMsg("❌ " + (e.response?.data?.error || e.message)); }
  };

  const addBatsman = (inningIdx) => {
    const updated = [...innings];
    updated[inningIdx].batting.push({ player_id:"", runs:0, balls:0, fours:0, sixes:0, out_status:"Not Out", dismissal_type:"", fielder_id:"", dismissal_bowler_id:"" });
    setInnings(updated);
  };

  const addBowler = (inningIdx) => {
    const updated = [...innings];
    updated[inningIdx].bowling.push({ player_id:"", overs:0, runs_conceded:0, wickets:0, maidens:0, wides:0, no_balls:0 });
    setInnings(updated);
  };

  const updateBat = (inningIdx, batIdx, field, val) => {
    const updated = [...innings];
    updated[inningIdx].batting[batIdx][field] = val;
    setInnings(updated);
  };

  const updateBowl = (inningIdx, bowlIdx, field, val) => {
    const updated = [...innings];
    updated[inningIdx].bowling[bowlIdx][field] = val;
    setInnings(updated);
  };

  const updateInning = (idx, field, val) => {
    const updated = [...innings];
    updated[idx][field] = val;
    setInnings(updated);
  };

  const submitAll = async () => {
    try {
      // Submit innings + scorecards
      await axios.post(`${API}/scoring/past-match`, { match_id: matchId, innings });
      // Submit result
      if (result.winning_team_id) {
        await axios.post(`${API}/matches/${matchId}/result`, result);
      }
      showMsg("✅ Match data saved successfully!");
      setStep(3);
    } catch (e) { showMsg("❌ " + (e.response?.data?.error || e.message)); }
  };

  const teamPlayers = (team_id) => players.filter(p => String(p.TEAM_ID) === String(team_id));

  return (
    <div>
      <h1 style={{ fontSize: 24, fontWeight: 800, marginBottom: 8 }}>📋 Enter Past Match Data</h1>
      <p style={{ color: "#888", marginBottom: 24, fontSize: 14 }}>Record historical match scorecards into the database.</p>

      {msg && (
        <div style={{ marginBottom: 16, padding: "10px 16px", borderRadius: 8, fontWeight: 600, fontSize: 13,
          background: msg.startsWith("✅") ? "#E8F5E9" : "#FFEBEE",
          color: msg.startsWith("✅") ? "#2E7D32" : "#C62828",
        }}>{msg}</div>
      )}

      {/* Step 1: Match Details */}
      <div style={{ background: "#FFF", border: "1px solid #E5E0D8", borderRadius: 12, padding: 24, marginBottom: 20 }}>
        <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16, color: step >= 1 ? "#1B5E20" : "#888" }}>
          Step 1 — Match Details {matchId && `✅ (Match #${matchId})`}
        </h2>
        {!matchId && (
          <>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              {[["TEAM 1","team1_id","select",(v)=>setMatchForm({...matchForm,team1_id:v})],
                ["TEAM 2","team2_id","select",(v)=>setMatchForm({...matchForm,team2_id:v})],
                ["VENUE","venue_id","venue",  (v)=>setMatchForm({...matchForm,venue_id:v})],
                ["FORMAT","match_format","format",(v)=>setMatchForm({...matchForm,match_format:v})],
                ["DATE","match_date","date",(v)=>setMatchForm({...matchForm,match_date:v})],
                ["TOSS DECISION","toss_decision","toss_d",(v)=>setMatchForm({...matchForm,toss_decision:v})],
              ].map(([label, key, type, handler]) => (
                <div key={key}>
                  <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>{label}</label>
                  {type === "select" ? (
                    <select style={inp} value={matchForm[key]} onChange={e => handler(e.target.value)}>
                      <option value="">Select</option>
                      {teams.map(t => <option key={t.TEAM_ID} value={t.TEAM_ID}>{t.TEAM_NAME}</option>)}
                    </select>
                  ) : type === "venue" ? (
                    <select style={inp} value={matchForm[key]} onChange={e => handler(e.target.value)}>
                      <option value="">Select Venue</option>
                      {venues.map(v => <option key={v.VENUE_ID} value={v.VENUE_ID}>{v.VENUE_NAME}</option>)}
                    </select>
                  ) : type === "format" ? (
                    <select style={inp} value={matchForm[key]} onChange={e => handler(e.target.value)}>
                      <option>T20</option><option>ODI</option><option>Test</option>
                    </select>
                  ) : type === "toss_d" ? (
                    <select style={inp} value={matchForm[key]} onChange={e => handler(e.target.value)}>
                      <option>Bat</option><option>Field</option>
                    </select>
                  ) : (
                    <input type="date" style={inp} value={matchForm[key]} onChange={e => handler(e.target.value)} />
                  )}
                </div>
              ))}
            </div>
            <button onClick={createMatch} style={btn()}>Create Match →</button>
          </>
        )}
      </div>

      {/* Step 2: Innings Data */}
      {step >= 2 && innings.map((inn, idx) => (
        <div key={idx} style={{ background: "#FFF", border: "1px solid #E5E0D8", borderRadius: 12, padding: 24, marginBottom: 20 }}>
          <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>Step 2 — Inning {inn.inning_number}</h2>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 12, marginBottom: 16 }}>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>BATTING TEAM</label>
              <select style={inp} value={inn.batting_team_id} onChange={e => updateInning(idx, "batting_team_id", e.target.value)}>
                <option value="">Select</option>
                {teams.filter(t => [String(matchForm.team1_id),String(matchForm.team2_id)].includes(String(t.TEAM_ID))).map(t => <option key={t.TEAM_ID} value={t.TEAM_ID}>{t.TEAM_NAME}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>BOWLING TEAM</label>
              <select style={inp} value={inn.bowling_team_id} onChange={e => updateInning(idx, "bowling_team_id", e.target.value)}>
                <option value="">Select</option>
                {teams.filter(t => [String(matchForm.team1_id),String(matchForm.team2_id)].includes(String(t.TEAM_ID))).map(t => <option key={t.TEAM_ID} value={t.TEAM_ID}>{t.TEAM_NAME}</option>)}
              </select>
            </div>
            {[["TOTAL RUNS","total_runs"],["WICKETS","total_wickets"],["OVERS","completed_overs"],["EXTRAS","extras_total"]].map(([label, field]) => (
              <div key={field}>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>{label}</label>
                <input type="number" min="0" style={inp} value={inn[field]} onChange={e => updateInning(idx, field, e.target.value)} />
              </div>
            ))}
          </div>

          {/* Batting */}
          <div style={{ marginBottom: 16 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, margin: 0 }}>Batting Scorecard</h3>
              <button onClick={() => addBatsman(idx)} style={{ ...btn("#1565C0"), padding: "6px 14px", fontSize: 12 }}>+ Batsman</button>
            </div>
            {inn.batting.map((b, bi) => (
              <div key={bi} style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr 1fr 2fr 2fr", gap: 8, marginBottom: 8 }}>
                <select style={{ ...inp, marginBottom: 0 }} value={b.player_id} onChange={e => updateBat(idx, bi, "player_id", e.target.value)}>
                  <option value="">Batsman</option>
                  {teamPlayers(inn.batting_team_id).map(p => <option key={p.PLAYER_ID} value={p.PLAYER_ID}>{p.PLAYER_NAME}</option>)}
                </select>
                {[["R","runs"],["B","balls"],["4s","fours"],["6s","sixes"]].map(([ph, f]) => (
                  <input key={f} type="number" min="0" placeholder={ph} style={{ ...inp, marginBottom: 0 }} value={b[f]} onChange={e => updateBat(idx, bi, f, e.target.value)} />
                ))}
                <select style={{ ...inp, marginBottom: 0 }} value={b.out_status} onChange={e => updateBat(idx, bi, "out_status", e.target.value)}>
                  <option>Not Out</option><option>Out</option><option>Retired Hurt</option>
                </select>
                <select style={{ ...inp, marginBottom: 0 }} value={b.dismissal_type} onChange={e => updateBat(idx, bi, "dismissal_type", e.target.value)}>
                  <option value="">How out?</option>
                  {["Bowled","Caught","LBW","Run Out","Stumped","Hit Wicket"].map(d => <option key={d}>{d}</option>)}
                </select>
              </div>
            ))}
          </div>

          {/* Bowling */}
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
              <h3 style={{ fontSize: 14, fontWeight: 700, margin: 0 }}>Bowling Scorecard</h3>
              <button onClick={() => addBowler(idx)} style={{ ...btn("#C62828"), padding: "6px 14px", fontSize: 12 }}>+ Bowler</button>
            </div>
            {inn.bowling.map((b, bi) => (
              <div key={bi} style={{ display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr 1fr 1fr", gap: 8, marginBottom: 8 }}>
                <select style={{ ...inp, marginBottom: 0 }} value={b.player_id} onChange={e => updateBowl(idx, bi, "player_id", e.target.value)}>
                  <option value="">Bowler</option>
                  {teamPlayers(inn.bowling_team_id).map(p => <option key={p.PLAYER_ID} value={p.PLAYER_ID}>{p.PLAYER_NAME}</option>)}
                </select>
                {[["Ov","overs"],["R","runs_conceded"],["W","wickets"],["M","maidens"],["Wd","wides"]].map(([ph, f]) => (
                  <input key={f} type="number" min="0" placeholder={ph} style={{ ...inp, marginBottom: 0 }} value={b[f]} onChange={e => updateBowl(idx, bi, f, e.target.value)} />
                ))}
              </div>
            ))}
          </div>
        </div>
      ))}

      {/* Step 3: Result */}
      {step >= 2 && (
        <div style={{ background: "#FFF", border: "1px solid #E5E0D8", borderRadius: 12, padding: 24, marginBottom: 20 }}>
          <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>Step 3 — Match Result</h2>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 12 }}>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>WINNING TEAM</label>
              <select style={inp} value={result.winning_team_id} onChange={e => setResult({ ...result, winning_team_id: e.target.value })}>
                <option value="">Select</option>
                {teams.filter(t => [String(matchForm.team1_id),String(matchForm.team2_id)].includes(String(t.TEAM_ID))).map(t => <option key={t.TEAM_ID} value={t.TEAM_ID}>{t.TEAM_NAME}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>WIN MARGIN</label>
              <input type="number" style={inp} value={result.win_margin} onChange={e => setResult({ ...result, win_margin: e.target.value })} />
            </div>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>MARGIN TYPE</label>
              <select style={inp} value={result.win_margin_type} onChange={e => setResult({ ...result, win_margin_type: e.target.value })}>
                {["Runs","Wickets","Draw","Tie","No Result"].map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>MAN OF MATCH</label>
              <select style={inp} value={result.man_of_match} onChange={e => setResult({ ...result, man_of_match: e.target.value })}>
                <option value="">Select</option>
                {players.map(p => <option key={p.PLAYER_ID} value={p.PLAYER_ID}>{p.PLAYER_NAME}</option>)}
              </select>
            </div>
            <div style={{ gridColumn: "span 2" }}>
              <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>RESULT DESCRIPTION</label>
              <input style={inp} placeholder="e.g. India won by 6 wickets" value={result.result_description} onChange={e => setResult({ ...result, result_description: e.target.value })} />
            </div>
          </div>
          <button onClick={submitAll} style={btn()}>💾 Save All Match Data</button>
        </div>
      )}

      {step === 3 && (
        <div style={{ background: "#E8F5E9", border: "1px solid #A5D6A7", borderRadius: 12, padding: 20, textAlign: "center" }}>
          <div style={{ fontSize: 24 }}>✅</div>
          <div style={{ fontWeight: 700, fontSize: 16, color: "#2E7D32", marginTop: 8 }}>Match data saved successfully!</div>
          <div style={{ fontSize: 13, color: "#388E3C", marginTop: 4 }}>You can view the scorecard in the Matches section.</div>
        </div>
      )}
    </div>
  );
}
import React, { useState, useEffect } from "react";
import axios from "axios";

const API = "http://localhost:5000/api";

const DISMISSALS = ["Bowled","Caught","LBW","Run Out","Stumped","Hit Wicket","Retired","Obstructing"];
const EXTRAS     = ["Wide","No-Ball","Bye","Leg-Bye"];

export default function LiveScoring() {
  const [step, setStep]         = useState("setup"); // setup | inning | over | ball
  const [teams, setTeams]       = useState([]);
  const [venues, setVenues]     = useState([]);
  const [players, setPlayers]   = useState([]);
  const [msg, setMsg]           = useState("");

  // Match setup
  const [matchForm, setMatchForm] = useState({
    team1_id:"", team2_id:"", venue_id:"", match_date: new Date().toISOString().split("T")[0],
    match_format:"T20", toss_winner_id:"", toss_decision:"Bat",
  });
  const [matchId, setMatchId]     = useState(null);

  // Inning setup
  const [inningForm, setInningForm] = useState({ batting_team_id:"", bowling_team_id:"", inning_number:1 });
  const [inningId, setInningId]     = useState(null);
  const [inningData, setInningData] = useState(null);

  // Over setup
  const [overForm, setOverForm] = useState({ bowler_id:"", over_number:1 });
  const [overId, setOverId]     = useState(null);
  const [overData, setOverData] = useState(null);

  // Ball entry
  const [ballForm, setBallForm] = useState({
    batsman_id:"", non_striker_id:"", runs_scored:0,
    is_wicket:"N", is_extra:"N", extra_type:"", extra_runs:0, dismissal_type:"", fielder_id:"",
  });
  const [ballNumber, setBallNumber] = useState(1);
  const [balls, setBalls]           = useState([]);

  useEffect(() => {
    Promise.all([axios.get(`${API}/teams`), axios.get(`${API}/venues`)])
      .then(([t, v]) => { setTeams(t.data); setVenues(v.data); });
  }, []);

  useEffect(() => {
    if (matchForm.team1_id && matchForm.team2_id) {
      axios.get(`${API}/players?team_id=${matchForm.team1_id}`)
        .then(r1 => axios.get(`${API}/players?team_id=${matchForm.team2_id}`)
          .then(r2 => setPlayers([...r1.data, ...r2.data])));
    }
  }, [matchForm.team1_id, matchForm.team2_id]);

  const inp = { width: "100%", padding: "9px 12px", borderRadius: 8, border: "1px solid #DDD", fontSize: 13, boxSizing: "border-box", marginBottom: 10, background: "#FFF" };
  const btn = (bg="#1B5E20", disabled=false) => ({
    background: disabled ? "#CCC" : bg, color: "#FFF", border: "none",
    borderRadius: 8, padding: "10px 20px", cursor: disabled ? "default" : "pointer",
    fontSize: 13, fontWeight: 600,
  });

  const showMsg = (m) => { setMsg(m); setTimeout(() => setMsg(""), 4000); };

  const createMatch = async () => {
    try {
      const r = await axios.post(`${API}/matches`, matchForm);
      setMatchId(r.data.match_id);
      setStep("inning");
      showMsg("✅ Match created! Now start the first inning.");
    } catch (e) { showMsg("❌ " + (e.response?.data?.error || e.message)); }
  };

  const startInning = async () => {
    try {
      const r = await axios.post(`${API}/innings`, { ...inningForm, match_id: matchId });
      setInningId(r.data.inning_id);
      setInningData(inningForm);
      setStep("over");
      showMsg("✅ Inning started! Now start an over.");
    } catch (e) { showMsg("❌ " + (e.response?.data?.error || e.message)); }
  };

  const startOver = async () => {
    try {
      const r = await axios.post(`${API}/innings/${inningId}/overs`, overForm);
      setOverId(r.data.over_id);
      setBallNumber(1);
      setBalls([]);
      setStep("ball");
      showMsg(`✅ Over ${overForm.over_number} started!`);
    } catch (e) { showMsg("❌ " + (e.response?.data?.error || e.message)); }
  };

  const recordBall = async () => {
    try {
      const payload = {
        over_id: overId, ball_number: ballNumber,
        ...ballForm,
        runs_scored: parseInt(ballForm.runs_scored) || 0,
        extra_runs:  parseInt(ballForm.extra_runs)  || 0,
        extra_type:  ballForm.is_extra === "Y" ? ballForm.extra_type : null,
        fielder_id:  ballForm.fielder_id || null,
        dismissal_type: ballForm.is_wicket === "Y" ? ballForm.dismissal_type : null,
      };
      const r = await axios.post(`${API}/scoring/ball`, payload);
      showMsg("✅ " + r.data.message);
      setBalls(prev => [...prev, { ...payload, msg: r.data.message }]);
      setBallNumber(prev => prev + 1);
      // Reset ball form
      setBallForm({ batsman_id:"", non_striker_id:"", runs_scored:0, is_wicket:"N", is_extra:"N", extra_type:"", extra_runs:0, dismissal_type:"", fielder_id:"" });
      if (ballNumber >= 6) {
        showMsg("✅ Over complete! Start next over.");
        setStep("over");
        setOverForm(p => ({ ...p, over_number: p.over_number + 1 }));
      }
    } catch (e) { showMsg("❌ " + (e.response?.data?.error || e.message)); }
  };

  const battingPlayers = players.filter(p => inningForm.batting_team_id && String(p.TEAM_ID) === String(inningForm.batting_team_id));
  const bowlingPlayers = players.filter(p => inningForm.bowling_team_id && String(p.TEAM_ID) === String(inningForm.bowling_team_id));

  return (
    <div>
      <h1 style={{ fontSize: 24, fontWeight: 800, marginBottom: 8 }}>📡 Live Scoring</h1>
      <p style={{ color: "#888", marginBottom: 24, fontSize: 14 }}>Enter ball-by-ball data in real time.</p>

      {msg && (
        <div style={{ marginBottom: 16, padding: "10px 16px", borderRadius: 8, fontWeight: 600, fontSize: 13,
          background: msg.startsWith("✅") ? "#E8F5E9" : "#FFEBEE",
          color: msg.startsWith("✅") ? "#2E7D32" : "#C62828",
          border: `1px solid ${msg.startsWith("✅") ? "#A5D6A7" : "#FFCDD2"}`,
        }}>{msg}</div>
      )}

      {/* Progress bar */}
      <div style={{ display: "flex", gap: 0, marginBottom: 28 }}>
        {["setup","inning","over","ball"].map((s, i) => (
          <div key={s} style={{ flex: 1, padding: "8px 0", textAlign: "center", fontSize: 12, fontWeight: 600,
            background: step === s ? "#1B5E20" : ["setup","inning","over","ball"].indexOf(step) > i ? "#A5D6A7" : "#EEE",
            color: step === s ? "#FFF" : ["setup","inning","over","ball"].indexOf(step) > i ? "#2E7D32" : "#999",
            borderRadius: i === 0 ? "8px 0 0 8px" : i === 3 ? "0 8px 8px 0" : 0,
          }}>
            {["1. Create Match","2. Start Inning","3. Start Over","4. Record Balls"][i]}
          </div>
        ))}
      </div>

      <div style={{ background: "#FFF", border: "1px solid #E5E0D8", borderRadius: 12, padding: 24 }}>

        {/* STEP 1: Match Setup */}
        {step === "setup" && (
          <div>
            <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>Create Match</h2>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>TEAM 1 *</label>
                <select style={inp} value={matchForm.team1_id} onChange={e => setMatchForm({ ...matchForm, team1_id: e.target.value })}>
                  <option value="">Select Team 1</option>
                  {teams.map(t => <option key={t.TEAM_ID} value={t.TEAM_ID}>{t.TEAM_NAME}</option>)}
                </select>
              </div>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>TEAM 2 *</label>
                <select style={inp} value={matchForm.team2_id} onChange={e => setMatchForm({ ...matchForm, team2_id: e.target.value })}>
                  <option value="">Select Team 2</option>
                  {teams.map(t => <option key={t.TEAM_ID} value={t.TEAM_ID}>{t.TEAM_NAME}</option>)}
                </select>
              </div>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>VENUE *</label>
                <select style={inp} value={matchForm.venue_id} onChange={e => setMatchForm({ ...matchForm, venue_id: e.target.value })}>
                  <option value="">Select Venue</option>
                  {venues.map(v => <option key={v.VENUE_ID} value={v.VENUE_ID}>{v.VENUE_NAME}</option>)}
                </select>
              </div>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>FORMAT *</label>
                <select style={inp} value={matchForm.match_format} onChange={e => setMatchForm({ ...matchForm, match_format: e.target.value })}>
                  <option>T20</option><option>ODI</option><option>Test</option>
                </select>
              </div>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>MATCH DATE *</label>
                <input style={inp} type="date" value={matchForm.match_date} onChange={e => setMatchForm({ ...matchForm, match_date: e.target.value })} />
              </div>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>TOSS WINNER</label>
                <select style={inp} value={matchForm.toss_winner_id} onChange={e => setMatchForm({ ...matchForm, toss_winner_id: e.target.value })}>
                  <option value="">Select</option>
                  {teams.filter(t => [matchForm.team1_id, matchForm.team2_id].includes(String(t.TEAM_ID))).map(t => <option key={t.TEAM_ID} value={t.TEAM_ID}>{t.TEAM_NAME}</option>)}
                </select>
              </div>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>TOSS DECISION</label>
                <select style={inp} value={matchForm.toss_decision} onChange={e => setMatchForm({ ...matchForm, toss_decision: e.target.value })}>
                  <option>Bat</option><option>Field</option>
                </select>
              </div>
            </div>
            <button onClick={createMatch} style={btn()}>Create Match →</button>
          </div>
        )}

        {/* STEP 2: Start Inning */}
        {step === "inning" && (
          <div>
            <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>Start Inning {inningForm.inning_number}</h2>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>BATTING TEAM</label>
                <select style={inp} value={inningForm.batting_team_id} onChange={e => setInningForm({ ...inningForm, batting_team_id: e.target.value, bowling_team_id: teams.find(t => String(t.TEAM_ID) !== e.target.value && [matchForm.team1_id, matchForm.team2_id].includes(String(t.TEAM_ID)))?.TEAM_ID || "" })}>
                  <option value="">Select</option>
                  {teams.filter(t => [String(matchForm.team1_id), String(matchForm.team2_id)].includes(String(t.TEAM_ID))).map(t => <option key={t.TEAM_ID} value={t.TEAM_ID}>{t.TEAM_NAME}</option>)}
                </select>
              </div>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>BOWLING TEAM</label>
                <select style={inp} value={inningForm.bowling_team_id} onChange={e => setInningForm({ ...inningForm, bowling_team_id: e.target.value })}>
                  <option value="">Select</option>
                  {teams.filter(t => [String(matchForm.team1_id), String(matchForm.team2_id)].includes(String(t.TEAM_ID))).map(t => <option key={t.TEAM_ID} value={t.TEAM_ID}>{t.TEAM_NAME}</option>)}
                </select>
              </div>
            </div>
            <button onClick={startInning} style={btn()}>Start Inning →</button>
          </div>
        )}

        {/* STEP 3: Start Over */}
        {step === "over" && (
          <div>
            <h2 style={{ fontSize: 16, fontWeight: 700, marginBottom: 16 }}>Start Over {overForm.over_number}</h2>
            <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>SELECT BOWLER</label>
            <select style={{ ...inp, maxWidth: 320 }} value={overForm.bowler_id} onChange={e => setOverForm({ ...overForm, bowler_id: e.target.value })}>
              <option value="">Select Bowler</option>
              {bowlingPlayers.map(p => <option key={p.PLAYER_ID} value={p.PLAYER_ID}>{p.PLAYER_NAME}</option>)}
            </select>
            <button onClick={startOver} style={btn()}>Start Over {overForm.over_number} →</button>
          </div>
        )}

        {/* STEP 4: Record Ball */}
        {step === "ball" && (
          <div>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <h2 style={{ fontSize: 16, fontWeight: 700, margin: 0 }}>
                Over {overForm.over_number} · Ball {ballNumber}
              </h2>
              <div style={{ display: "flex", gap: 6 }}>
                {balls.map((b, i) => (
                  <div key={i} style={{
                    width: 32, height: 32, borderRadius: "50%", display: "flex",
                    alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700,
                    background: b.is_wicket === "Y" ? "#FFEBEE" : b.is_extra === "Y" ? "#FFF8E1" : "#E8F5E9",
                    color: b.is_wicket === "Y" ? "#C62828" : b.is_extra === "Y" ? "#F57F17" : "#2E7D32",
                    border: `2px solid ${b.is_wicket === "Y" ? "#C62828" : b.is_extra === "Y" ? "#F57F17" : "#2E7D32"}`,
                  }}>
                    {b.is_wicket === "Y" ? "W" : b.is_extra === "Y" ? "E" : b.runs_scored}
                  </div>
                ))}
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>BATSMAN (ON STRIKE)</label>
                <select style={inp} value={ballForm.batsman_id} onChange={e => setBallForm({ ...ballForm, batsman_id: e.target.value })}>
                  <option value="">Select</option>
                  {battingPlayers.map(p => <option key={p.PLAYER_ID} value={p.PLAYER_ID}>{p.PLAYER_NAME}</option>)}
                </select>
              </div>
              <div>
                <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>NON-STRIKER</label>
                <select style={inp} value={ballForm.non_striker_id} onChange={e => setBallForm({ ...ballForm, non_striker_id: e.target.value })}>
                  <option value="">Select</option>
                  {battingPlayers.map(p => <option key={p.PLAYER_ID} value={p.PLAYER_ID}>{p.PLAYER_NAME}</option>)}
                </select>
              </div>
            </div>

            {/* Runs */}
            <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 8 }}>RUNS SCORED</label>
            <div style={{ display: "flex", gap: 8, marginBottom: 14 }}>
              {[0,1,2,3,4,6].map(r => (
                <button key={r} onClick={() => setBallForm({ ...ballForm, runs_scored: r })}
                  style={{ width: 44, height: 44, borderRadius: "50%", border: "2px solid", cursor: "pointer", fontWeight: 700, fontSize: 15,
                    borderColor: ballForm.runs_scored === r ? "#1B5E20" : "#DDD",
                    background: ballForm.runs_scored === r ? "#1B5E20" : "#FFF",
                    color: ballForm.runs_scored === r ? "#FFF" : "#333",
                  }}>{r}</button>
              ))}
              <input type="number" placeholder="5" min="0" style={{ width: 60, padding: "8px", borderRadius: 8, border: "1px solid #DDD", fontSize: 14, textAlign: "center" }}
                onChange={e => setBallForm({ ...ballForm, runs_scored: parseInt(e.target.value)||0 })} />
            </div>

            {/* Extra / Wicket toggles */}
            <div style={{ display: "flex", gap: 12, marginBottom: 14 }}>
              <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13 }}>
                <input type="checkbox" checked={ballForm.is_extra === "Y"} onChange={e => setBallForm({ ...ballForm, is_extra: e.target.checked ? "Y" : "N", extra_type: "" })} />
                Extra
              </label>
              <label style={{ display: "flex", alignItems: "center", gap: 8, cursor: "pointer", fontSize: 13 }}>
                <input type="checkbox" checked={ballForm.is_wicket === "Y"} onChange={e => setBallForm({ ...ballForm, is_wicket: e.target.checked ? "Y" : "N", dismissal_type: "" })} />
                Wicket
              </label>
            </div>

            {ballForm.is_extra === "Y" && (
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 14 }}>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>EXTRA TYPE</label>
                  <select style={inp} value={ballForm.extra_type} onChange={e => setBallForm({ ...ballForm, extra_type: e.target.value })}>
                    <option value="">Select</option>
                    {EXTRAS.map(e => <option key={e}>{e}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>EXTRA RUNS</label>
                  <input type="number" min="0" style={inp} value={ballForm.extra_runs} onChange={e => setBallForm({ ...ballForm, extra_runs: parseInt(e.target.value)||0 })} />
                </div>
              </div>
            )}

            {ballForm.is_wicket === "Y" && (
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 14 }}>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>DISMISSAL TYPE</label>
                  <select style={inp} value={ballForm.dismissal_type} onChange={e => setBallForm({ ...ballForm, dismissal_type: e.target.value })}>
                    <option value="">Select</option>
                    {DISMISSALS.map(d => <option key={d}>{d}</option>)}
                  </select>
                </div>
                <div>
                  <label style={{ fontSize: 11, fontWeight: 700, color: "#888", display: "block", marginBottom: 4 }}>FIELDER (if caught/stumped)</label>
                  <select style={inp} value={ballForm.fielder_id} onChange={e => setBallForm({ ...ballForm, fielder_id: e.target.value })}>
                    <option value="">None</option>
                    {bowlingPlayers.map(p => <option key={p.PLAYER_ID} value={p.PLAYER_ID}>{p.PLAYER_NAME}</option>)}
                  </select>
                </div>
              </div>
            )}

            <button onClick={recordBall} style={btn("#1B5E20", !ballForm.batsman_id || !ballForm.non_striker_id)} disabled={!ballForm.batsman_id || !ballForm.non_striker_id}>
              Record Ball {ballNumber} →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
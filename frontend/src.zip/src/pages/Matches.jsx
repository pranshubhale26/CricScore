import React, { useEffect, useState } from "react";
import axios from "axios";
import Scorecard from "../components/Scorecard";

const API = "http://localhost:5000/api";

function StatusBadge({ status }) {
  const map = {
    Live:      { bg: "#FFEBEE", color: "#C62828" },
    Completed: { bg: "#E8F5E9", color: "#2E7D32" },
    Scheduled: { bg: "#FFF8E1", color: "#F57F17" },
    Abandoned: { bg: "#EEEEEE", color: "#616161" },
  };
  const s = map[status] || map.Abandoned;
  return (
    <span style={{ background: s.bg, color: s.color, fontSize: 11, fontWeight: 700, padding: "3px 10px", borderRadius: 20 }}>
      {status}
    </span>
  );
}

export default function Matches({ selectedMatch, setSelectedMatch }) {
  const [matches, setMatches]   = useState([]);
  const [detail, setDetail]     = useState(null);
  const [loading, setLoading]   = useState(true);
  const [detailLoading, setDL]  = useState(false);

  useEffect(() => {
    axios.get(`${API}/matches`)
      .then(r => { setMatches(r.data); setLoading(false); })
      .catch(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (selectedMatch) loadDetail(selectedMatch);
  }, [selectedMatch]);

  const loadDetail = (id) => {
    setDL(true);
    axios.get(`${API}/matches/${id}`)
      .then(r => { setDetail(r.data); setDL(false); })
      .catch(() => setDL(false));
  };

  if (detail) return (
    <div>
      <button
        onClick={() => { setDetail(null); setSelectedMatch(null); }}
        style={{ background: "none", border: "1px solid #CCC", borderRadius: 8, padding: "8px 16px", cursor: "pointer", marginBottom: 20, fontSize: 13 }}
      >
        ← Back to Matches
      </button>

      {/* Match header */}
      <div style={{ background: "#1B5E20", borderRadius: 12, padding: "24px 28px", color: "#FFF", marginBottom: 24 }}>
        <div style={{ fontSize: 22, fontWeight: 800 }}>
          {detail.TEAM1} <span style={{ opacity: 0.6 }}>vs</span> {detail.TEAM2}
        </div>
        <div style={{ marginTop: 8, display: "flex", gap: 20, fontSize: 13, opacity: 0.85 }}>
          <span>📅 {detail.MATCH_DATE ? new Date(detail.MATCH_DATE).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" }) : "-"}</span>
          <span>🏟️ {detail.VENUE_NAME}, {detail.CITY}</span>
          <span>🎯 {detail.MATCH_FORMAT}</span>
          {detail.SERIES_NAME && <span>🏆 {detail.SERIES_NAME}</span>}
        </div>
        {detail.RESULT_DESCRIPTION && (
          <div style={{ marginTop: 12, background: "rgba(255,255,255,0.15)", borderRadius: 8, padding: "10px 16px", fontSize: 14, fontWeight: 600 }}>
            🏆 {detail.RESULT_DESCRIPTION}
          </div>
        )}
        <div style={{ marginTop: 12, display: "flex", gap: 16, fontSize: 12 }}>
          {detail.TOSS_WINNER && <span>🪙 Toss: {detail.TOSS_WINNER} chose to {detail.TOSS_DECISION}</span>}
          {detail.MAN_OF_MATCH && <span>⭐ MoM: {detail.MAN_OF_MATCH}</span>}
          <StatusBadge status={detail.STATUS} />
        </div>
      </div>

      {detailLoading ? <div>Loading scorecard...</div> : <Scorecard innings={detail.innings} />}
    </div>
  );

  return (
    <div>
      <h1 style={{ fontSize: 24, fontWeight: 800, marginBottom: 24 }}>All Matches</h1>

      {loading ? <div style={{ color: "#888" }}>Loading...</div> : (
        <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
          {matches.map((m) => (
            <div
              key={m.MATCH_ID}
              onClick={() => loadDetail(m.MATCH_ID)}
              style={{
                background: "#FFF", border: "1px solid #E5E0D8", borderRadius: 12,
                padding: "18px 24px", cursor: "pointer",
                transition: "box-shadow 0.15s",
                display: "flex", justifyContent: "space-between", alignItems: "center",
              }}
              onMouseEnter={e => e.currentTarget.style.boxShadow = "0 4px 16px rgba(0,0,0,0.08)"}
              onMouseLeave={e => e.currentTarget.style.boxShadow = "none"}
            >
              <div>
                <div style={{ fontWeight: 700, fontSize: 16 }}>
                  {m.TEAM1} <span style={{ color: "#888" }}>vs</span> {m.TEAM2}
                </div>
                <div style={{ fontSize: 12, color: "#888", marginTop: 4 }}>
                  {m.VENUE_NAME && `${m.VENUE_NAME}, `}{m.CITY}
                  {m.MATCH_DATE && ` · ${new Date(m.MATCH_DATE).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" })}`}
                  {m.SERIES_NAME && ` · ${m.SERIES_NAME}`}
                </div>
                {m.RESULT_DESCRIPTION && (
                  <div style={{ fontSize: 12, color: "#2E7D32", marginTop: 4, fontWeight: 600 }}>
                    🏆 {m.RESULT_DESCRIPTION}
                  </div>
                )}
              </div>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 8 }}>
                <StatusBadge status={m.STATUS} />
                <span style={{ background: "#E8F5E9", color: "#2E7D32", fontSize: 11, fontWeight: 700, padding: "2px 8px", borderRadius: 10 }}>
                  {m.MATCH_FORMAT}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
import React, { useEffect, useState } from "react";
import axios from "axios";

const API = "http://localhost:5000/api";

function StatCard({ label, value, color = "#1B5E20", icon }) {
  return (
    <div style={{
      background: "#FFF", border: "1px solid #E5E0D8", borderRadius: 12,
      padding: "20px 24px", flex: 1, minWidth: 140,
      borderTop: `4px solid ${color}`,
    }}>
      <div style={{ fontSize: 32, fontWeight: 800, color }}>{value ?? "-"}</div>
      <div style={{ fontSize: 12, color: "#888", marginTop: 4, fontWeight: 600 }}>
        {icon} {label}
      </div>
    </div>
  );
}

function StatusBadge({ status }) {
  const map = {
    Live:      { bg: "#FFEBEE", color: "#C62828" },
    Completed: { bg: "#E8F5E9", color: "#2E7D32" },
    Scheduled: { bg: "#FFF8E1", color: "#F57F17" },
    Abandoned: { bg: "#EEEEEE", color: "#616161" },
  };
  const s = map[status] || map.Abandoned;
  return (
    <span style={{
      background: s.bg, color: s.color,
      fontSize: 11, fontWeight: 700, padding: "3px 10px",
      borderRadius: 20, display: "inline-block",
    }}>{status}</span>
  );
}

export default function Dashboard({ setPage, setSelectedMatch }) {
  const [data, setData]   = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    axios.get(`${API}/stats/dashboard`)
      .then(r => setData(r.data))
      .catch(() => setError("Cannot connect to backend. Make sure the Node.js server is running on port 5000."));
  }, []);

  if (error) return (
    <div style={{ background: "#FFEBEE", border: "1px solid #FFCDD2", borderRadius: 12, padding: 24, color: "#C62828" }}>
      ❌ {error}
    </div>
  );

  if (!data) return <div style={{ color: "#888", padding: 40 }}>Loading...</div>;

  return (
    <div>
      {/* Header */}
      <div style={{ marginBottom: 28 }}>
        <h1 style={{ fontSize: 28, fontWeight: 800, color: "#1A1A1A", margin: 0 }}>
          🏏 Cricket Scoring System
        </h1>
      </div>

      {/* Stat cards */}
      <div style={{ display: "flex", gap: 16, marginBottom: 28, flexWrap: "wrap" }}>
        <StatCard label="Teams"          value={data.counts.teams}   color="#1B5E20" icon="👥" />
        <StatCard label="Active Players" value={data.counts.players} color="#1565C0" icon="🧑" />
        <StatCard label="Matches"        value={data.counts.matches} color="#6A1B9A" icon="🏏" />
        <StatCard label="Venues"         value={data.counts.venues}  color="#E65100" icon="🏟️" />
        <StatCard label="Live Now"       value={data.counts.live}    color="#C62828" icon="📡" />
      </div>

      {/* Recent matches */}
      <div style={{ background: "#FFF", border: "1px solid #E5E0D8", borderRadius: 12, overflow: "hidden" }}>
        <div style={{
          padding: "16px 24px", borderBottom: "1px solid #E5E0D8",
          display: "flex", justifyContent: "space-between", alignItems: "center",
        }}>
          <h2 style={{ margin: 0, fontSize: 16, fontWeight: 700 }}>Recent Matches</h2>
          <button
            onClick={() => setPage("matches")}
            style={{ background: "#1B5E20", color: "#FFF", border: "none", borderRadius: 8, padding: "7px 16px", cursor: "pointer", fontSize: 13, fontWeight: 600 }}
          >
            View All
          </button>
        </div>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr style={{ background: "#FAFAF8" }}>
              {["Match", "Format", "Venue", "Date", "Result", "Status"].map(h => (
                <th key={h} style={{ padding: "10px 16px", textAlign: "left", fontSize: 11, fontWeight: 700, color: "#888", textTransform: "uppercase", borderBottom: "1px solid #E5E0D8" }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {(data.recentMatches || []).map((m, i) => (
              <tr
                key={i}
                onClick={() => { setSelectedMatch(m.MATCH_ID); setPage("matches"); }}
                style={{ cursor: "pointer", background: i % 2 === 0 ? "#FFF" : "#FAFAF8" }}
                onMouseEnter={e => e.currentTarget.style.background = "#F1F8E9"}
                onMouseLeave={e => e.currentTarget.style.background = i % 2 === 0 ? "#FFF" : "#FAFAF8"}
              >
                <td style={{ padding: "12px 16px", fontWeight: 600, fontSize: 13 }}>
                  {m.TEAM1} <span style={{ color: "#888" }}>vs</span> {m.TEAM2}
                </td>
                <td style={{ padding: "12px 16px", fontSize: 12 }}>
                  <span style={{ background: "#E8F5E9", color: "#2E7D32", padding: "2px 8px", borderRadius: 10, fontWeight: 600 }}>
                    {m.MATCH_FORMAT}
                  </span>
                </td>
                <td style={{ padding: "12px 16px", fontSize: 12, color: "#666" }}>{m.CITY || "-"}</td>
                <td style={{ padding: "12px 16px", fontSize: 12, color: "#666" }}>
                  {m.MATCH_DATE ? new Date(m.MATCH_DATE).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" }) : "-"}
                </td>
                <td style={{ padding: "12px 16px", fontSize: 12, color: "#333" }}>{m.RESULT_DESCRIPTION || "-"}</td>
                <td style={{ padding: "12px 16px" }}><StatusBadge status={m.STATUS} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}